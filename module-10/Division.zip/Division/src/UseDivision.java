// Program created by Liz Hinz for CSD402-A339 
// M10 Programming Assignment for Division classes - Use Division Class

public class UseDivision {
	public static void main(String[] args) {
		// Two instances from Domestic divison class 
		InternationalDivision internationalDivision1 = new InternationalDivision("International Sales", "4126", "Australia", "English");
		InternationalDivision internationalDivision2 = new InternationalDivision("International Accounting", "4102", "Canada", "French");

		
		// Two instances from Domestic division class 
		DomesticDivsion domesticDivison1 = new DomesticDivsion("Local Sales", "2123", "Arizona");
		DomesticDivsion domesticDivison2 = new DomesticDivsion("Local Accounting", "2172", "New York");

		// Display all four instances 
		internationalDivision1.display();
		internationalDivision2.display();
		domesticDivison1.display();
		domesticDivison2.display();

	}
}