// Program created by Liz Hinz for CSD402-A339 
// M10 Programming Assignment for Division classes  - Domestic Division class

class DomesticDivsion extends Division {
	private String state;
	
	// Super class and state field
	public DomesticDivsion(String divisionName, String accountNumber, String state) {
		super(divisionName, accountNumber);
		this.state = state;
	}

	@Override 
	public void display() { 
		System.out.println("\nDomestic Division: ");
		System.out.println("Division Name: " + getDivisionName());
		System.out.println("Account Number: " + getAccountNumber());
		System.out.println("State: " + state);
	}
}
