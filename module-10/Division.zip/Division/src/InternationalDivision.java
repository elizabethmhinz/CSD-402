// Program created by Liz Hinz for CSD402-A339 
// M10 Programming Assignment for Division classes - International Division class

class InternationalDivision extends Division {
	private String country;
	private String language;

	// super class, country field, language field 
	public InternationalDivision(String divisionName, String accountNumber, String country, String language) {
		super(divisionName, accountNumber); 
		this.country = country;
		this.language = language; 
}

	@Override 
	public void display() { 
		System.out.println("\nInternational Division: ");
		System.out.println("Division Name: " + getDivisionName());
		System.out.println("Account Number: " + getAccountNumber());
		System.out.println("Country: " + country);
		System.out.println("Language: " + language);
	}

}