// Program created by Liz Hinz for CSD402-A339 
// M10 Programming Assignment for Division classes - Division class 

abstract class Division {
	private String divisionName;
	private String accountNumber;
		
	public Division(String divisionName, String accountNumber) {
		this.divisionName = divisionName;
		this.accountNumber = accountNumber;
	}
	
	public String getDivisionName() {
		return divisionName;
		
	}
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	// abstract display method
	void display() {
	} 
}