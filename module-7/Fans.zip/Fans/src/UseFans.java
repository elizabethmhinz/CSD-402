//Program created by Liz Hinz for CSD402-A339: Java for Programmers
//Assignment M7 Programming Assignment
//This program controls a collection of fan instances.  

import java.util.ArrayList;
import java.util.List; 

public class UseFans {
	// Display method for single instance of a fan in place of toString() 
	public static void displayFan(Fans fan) {
		System.out.println("Fan Status: " + (fan.isOn() ? "On" : "Off"));
		System.out.println("Fan Speed: " + (fan.isOn() ? fan.getSpeed(): "No speed, fan is off."));
		System.out.println("Fan Radius: " + (fan.getRadius() ));
		System.out.println("Fan Color: " + (fan.getColor() ));
		System.out.println("-----------------------------------------");

	}
	// Display method for collection of Fan instances 
	public static void displayFansList(List<Fans> fansList) {
		System.out.println("Displaying all fans in collection: \n");
		for (Fans fan : fansList) {
			displayFan(fan);
		}
	}
	
	public static void main(String[] args) {
		// Collection for fans
		List<Fans> fansCollection = new ArrayList<>();
		
		// Fans for collection
		fansCollection.add(new Fans(Fans.SLOW, true, 8.5, "White"));
		fansCollection.add(new Fans(Fans.MEDIUM, true, 7.5, "Black"));
		fansCollection.add(new Fans(Fans.FAST, true, 9.5, "Green"));
		fansCollection.add(new Fans(Fans.STOPPED, false, 10.0, "Blue"));

		// Display each fan 
		System.out.println("Displaying individual fans:\n");
		for (Fans fan: fansCollection) {
			displayFan(fan);
		}
		
		// Display all fans 
		displayFansList(fansCollection);
	}
} 
	