// Program created by Liz Hinz for CSD402-A339: Java for Programmers
// Assignment M3 Programming Assignment


//printing pattern found from Pattern of Number with Mirror Image on https://www.geeksforgeeks.org/programs-printing-pyramid-patterns-java/ 
//only used reversed pattern 
// Main Function


public class NestedLoopAssignment {
    public static void main(String[] args) {
        int rows = 7; // Number of Rows we want to print

        // Printing the pyramid pattern
        for (int i = 1; i <= rows; i++) {
            // Print leading spaces before the numbers
            for (int j = rows; j > i; j--) {
                System.out.print("  "); // Adjust the spacing here
            }

            // Print the numbers in the current row
            int num = 1;
            for (int j = 1; j <= i; j++) {
                System.out.print(num + " ");
                num = num * 2;
            }
            for (int j = i - 1; j >= 1; j--) {
                num = num / 2;
                System.out.print(num + " ");
            }

            // Print spaces after the numbers to align the @ symbols
            for (int j = rows - i; j > 0; j--) {
                System.out.print("   "); // Adjust the spacing here
            }

            // Print the @ symbol at the end of the row
            System.out.print(" @");
            // Move to the next line after printing the @ symbol
            System.out.println();
        }
    }
}