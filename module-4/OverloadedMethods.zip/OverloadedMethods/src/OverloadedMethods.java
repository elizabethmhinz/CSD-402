/* Program created by Liz Hinz for CSD402-A339 
 * January 26, 2025
 * Program with four overloaded methods that return the average of an array. 
*/

import java.util.Arrays;
public class OverloadedMethods {
	public static void main(String[] args) {
		// declare int list, short list, long list, and double list for tests
		// vary array lengths to ensure code is working correctly. 
		
		short[] shortList = {4, 6, 32, 11, 72, 45};
		System.out.println("Short Array: " + Arrays.toString(shortList));
		System.out.println("The average of the short array is " + average(shortList) + ".");
		
		int[] intList = {3, 6, 21, 24, 12, 13, 7, 8};
		System.out.println("\nInt Array: " + Arrays.toString(intList));
		System.out.println("The average of the int array is " + average(intList) + ".");
	
		long[] longList = {5L, 19L, 22L, 21L, 52L};
		System.out.println("\nLong Array: " + Arrays.toString(longList));
		System.out.println("The average of the long array is " + average(longList) + ".");
	
		double[] doubleList = {7.2, 19.1, 22.6, 15.3, 52.2, 51.1, 87.7};
		System.out.println("\nDouble Array: " + Arrays.toString(doubleList));
		System.out.println("The average of the double array is " + average(doubleList) + ".");
	}
	
	// provided header short average
	public static short average(short[] array) {
		int sum = 0;
		for (short num: array) {
			sum += num; 
		}
		return (short) (sum/array.length);
	}
	
	// provided header int average
	public static int average(int[] array) {
		int sum = 0;
		for (int num: array) {
			sum += num; 
		}
		return sum / array.length;
	}
	
	// provided header long average
	public static long average(long[] array) {
		long sum = 0;
		for (long num: array) {
			sum += num; 
		}
		return sum / array.length;
	}
	
	// provided header double average 
	public static double average(double[] array) {
		double sum = 0.0;
		for (double num: array) {
			sum += num; 
		}
		return (short) (sum/array.length);
	}
}