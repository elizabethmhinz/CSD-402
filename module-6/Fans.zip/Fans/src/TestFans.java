// Fans test for Fans class created by Liz Hinz for CSD402-A339 M6 Programming Assignment 
public class TestFans {
	public static void main(String[] args) {
		// Fan with default
		Fans fan1 = new Fans();
		System.out.println("Fan 1: " + fan1.toString());
		
		// fan with argument constructor 
		Fans fan2 = new Fans(Fans.MEDIUM, true, 4.0, "black");
		System.out.println("Fan 2: " + fan2.toString());
		
		fan1.setSpeed(Fans.FAST);
		fan1.setOn(true);
		fan1.setRadius(7.0);
		fan1.setColor("green");
		
		System.out.println("Updated Fan 1: " + fan1.toString());
		
		fan1.setSpeed(6);
		
		fan1.setRadius(-1.1);
		
		System.out.println("Final Fan 1: " + fan1.toString());
		System.out.println("Final Fan 2: " + fan2.toString());
	}
}
