//Program created by Liz Hinz for CSD402-A339: Java for Programmers
//Assignment M6 Programming Assignment
//This program controls a fan. 
public class Fans {
	// constant speeds 
	public static final int STOPPED = 0;
	public static final int SLOW = 1;
	public static final int MEDIUM = 2;
	public static final int FAST = 3;
	
	// private fields 
	private boolean on; 
	private String color;
	private int speed; 
	private double radius; 
	
	// No-argument constructors 
	public Fans() {
		this.speed = STOPPED;
		this.on = false;
		this.radius = 6.0;
		this.color = "white";
	}
	
	// Constructors with parameters 
	public Fans(int speed, boolean on, double radius, String color) {
		this.speed = speed;
		this.on = on;
		this.radius = radius;
		this.color = color;
	}
	
	// getter and setter methods for all mutable fields 
	public int getSpeed() {
		return speed; 
	}
	
	public void setSpeed(int speed) {
		if (speed >=STOPPED && speed <= FAST) {
			this.speed = speed;
		} else	{
			System.out.println("Error: Invalid input.");
		}
	}
	
	public boolean isOn() {
		return on;
	}

	public void setOn(boolean on) {
		this.on = on;
	}

	public double getRadius() {
		return radius;
	}	
	
	
	public void setRadius(double radius) {
		if (radius > 0) {
			this.radius = radius;
		} else {
			System.out.println("Error: Invalid input.");
		}
	}
	
	public String getColor() {
		return color; 
	}
	
	public void setColor(String color) {
		this.color = color; 
	}

	// String for fans state 
	public String toString() {
		if (on) {
			return "Fan is on. The speed is " + speed + ". Radius is " + radius + ". Color is " + color + ".";
		}
		else {
			return "Fan is off. Radius is " + radius + ". Color is " + color + ".";
		}
	}
	
}