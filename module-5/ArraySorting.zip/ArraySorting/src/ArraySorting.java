/* Liz Hinz - CSD402-A339 Java for Programming 
 * M5 Programming Assignment - February 2, 2025
This program generates the smallest element in the array.
*/
import java.util.*; 

public class ArraySorting {
	public static void main(String[] args) {
		// Declare int and double array
		int[][] intArray = {
			{21, 43, 74, 32, 62},
			{17, 34, 12, 46, 21}
		};
		
		double[][] doubleArray = {
			{12, 5, 8, 16, 56.9},
			{16, 41, 23, 53, 12.1}
		};
		// Find largest int in array
		int[]largestIntLocation = locateLargest(intArray);
		System.out.println("Largest int located at: [" + largestIntLocation[0] + "]["+ largestIntLocation[1]+ "]" + " Value: " + intArray[largestIntLocation[0]][largestIntLocation[1]]);
		
		// Find smallest int in array
		int[]smallestIntLocation = locateSmallest(intArray);
		System.out.println("Smallest int located at: [" + smallestIntLocation[0] + "][" + smallestIntLocation[1] + "]" + " Value: " + intArray[smallestIntLocation[0]][smallestIntLocation[1]]);
		
		// Find largest double in array
		int[]largestDoubleLocation = locateLargest(doubleArray);
		System.out.println("Largest double located at: [" + largestDoubleLocation[0] + "]["+ largestDoubleLocation[1]+ "]" + " Value: " + doubleArray[largestDoubleLocation[0]][largestDoubleLocation[1]]);
		
		// Find smallest double in array
		int[]smallestDoubleLocation = locateSmallest(doubleArray);
		System.out.println("Smallest double located at: [" + smallestDoubleLocation[0] + "][" + smallestDoubleLocation[1] + "]" + " Value: " + doubleArray[smallestDoubleLocation[0]][smallestDoubleLocation[1]]);
	}
	// provided header - locate largest int
	public static int[] locateLargest(int[][]arrayParam) {
		int[] location = {0, 0};
		int max = arrayParam[0][0];
		
		// for loop based on 7.5 example 
	    for (int i = 0; i < arrayParam.length; i++) {
	    	for (int j = 0; j < arrayParam[i].length; j++) {
	    		if (arrayParam[i][j] > max) {
	    			max = arrayParam[i][j];
	    			location[0] = i;
	    			location[1] = j;
	    		}	
	    	}
	    }
		return location;
	}
	
	// provided header - locate largest double
	public static int[] locateLargest(double[][]arrayParam) {
		int[] location = {0, 0};
		double max = arrayParam[0][0];
		
	    for (int i = 0; i < arrayParam.length; i++) {
	    	for (int j = 0; j < arrayParam[i].length; j++) {
	    		if (arrayParam[i][j] > max) {
	    			max = arrayParam[i][j];
	    			location[0] = i;
	    			location[1] = j;
	    		}
	    	}
	    }
		return location;
	}
	
	// provided header - locate smallest int
	public static int[] locateSmallest(int[][]arrayParam) {
		int[] location = {0, 0};
		int min = arrayParam[0][0];
		
		for (int i = 0; i < arrayParam.length; i++) {
			for (int j = 0; j < arrayParam[i].length; j++) {
		    	if (arrayParam[i][j] < min) {
		    		min = arrayParam[i][j];
		    		location[0] = i;
		    		location[1] = j;
		    	}
			}
		}
		return location;
	}
	
	// provided header - locate smallest double 
	public static int[] locateSmallest(double[][]arrayParam) {
		int[] location = {0, 0};
		double min = arrayParam[0][0];
		
		for (int i = 0; i < arrayParam.length; i++) {
			for (int j = 0; j < arrayParam[i].length; j++) {
				if (arrayParam[i][j] < min) {
			    	min = arrayParam[i][j];
			    	location[0] = i;
			    	location[1] = j;
			    }
			}
		}
		return location;
	}
}