// Code for M12 Redo Assignment (Redoing Assignment M11 Program)
// Created by Liz Hinz for CSD402-A339 - Accordion Example
// Code adjusted from Tutorialspoint website under the JavaFX Accordion article 
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Accordion1 extends Application {
   @Override
   public void start(Stage stage) {
      //Creating the first TitledPane
      TitledPane paneOne = new TitledPane();
      paneOne.setText("Your Name");
      paneOne.setContent(new Label("My name is: \nLiz Hinz"));
      //Creating the second TitledPane
      TitledPane paneTwo = new TitledPane();
      paneTwo.setText("Class");
      paneTwo.setContent(new Label("This program is created for class: \nJava for Programmers \nCSD402-A339"));
      //Creating the third TitledPane
      TitledPane paneThree = new TitledPane();
      paneThree.setText("School");
      paneThree.setContent(new Label("My school is: \nBellevue University"));
      
      //Creating an Accordion for all TitledPane
      Accordion accordionNew = new Accordion();
      accordionNew.getPanes().addAll(paneOne, paneTwo, paneThree);
      accordionNew.setExpandedPane(paneOne);
      VBox root = new VBox(accordionNew);
      //Setting the stage
      Scene scene = new Scene(root, 500, 500, Color.GREEN);
      stage.setTitle("Accordion in JavaFX");
      stage.setScene(scene);
      stage.show();
   }
   public static void main(String args[]){
      launch(args);
   }
}   