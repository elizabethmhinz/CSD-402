// Program created by Liz Hinz for CSD402-A339: Java for Programmers
// Programming Assignment 12.2
public class YearlyService {

	private final double standardServiceCharge = 75.00;

	// returns standard service charge
	public double yearlyService() {
		return standardServiceCharge;
	}
	
	// returns standard service charge + oil change fee
	public double yearlyService(double oilChange) {
		return standardServiceCharge + oilChange;

	}
	
	// returns standard service charge, oil change fee, & tire rotation
	public double yearlyService(double oilChange, double tireRotation) {
		return standardServiceCharge + oilChange + tireRotation;
	}
	
	// returns standard service charge, oil change fee, tire rotation, with a coupon amount
	// that is deducted from total cost
	public double yearlyService(double oilChange, double tireRotation, double coupon) {
		return standardServiceCharge + oilChange + tireRotation - coupon;

	}

	// test each method twice
	public static void main(String[] args) {
		YearlyService service = new YearlyService();
		// test yearlyService method
		System.out.println("Standard Service Charge 1: " + service.yearlyService());
		System.out.println("Standard Service Charge 2: " + service.yearlyService());
		
		// tests yearlyService method with oil change
		double oilChange1 = 45.0;
		double oilChange2 = 50.0;
		System.out.println("Standard Service Charge with Oil Change 1: " + service.yearlyService(oilChange1));
		System.out.println("Standard Service Charge with Oil Change 2: " + service.yearlyService(oilChange2));
		
		// tests yearlyService method with oil change & tire rotation
		double tireRotation1 = 15.0;
		double tireRotation2 = 25.0;
		System.out.println("Standard Service Charge with Oil Change and Tire Rotation 1: " + service.yearlyService(oilChange1, tireRotation1));
		System.out.println("Standard Service Charge with Oil Change and Tire Rotation 2: " + service.yearlyService(oilChange2, tireRotation2));

		// tests yearlyService method with oil change, tire rotation
		double coupon1 = 15.0;
		double coupon2 = 10.0;
		System.out.println("Standard Service Charge with Oil Change, Tire Rotation, and Coupon 1: " + service.yearlyService(oilChange1, tireRotation1, coupon1));
		System.out.println("Standard Service Charge with Oil Change, Tire Rotation, and Coupon 2: " + service.yearlyService(oilChange2, tireRotation2, coupon2));

	}
}

